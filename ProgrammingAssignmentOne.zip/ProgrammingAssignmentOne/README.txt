# Programming Assignment 1
Requires Java 8 to run. Add relevant commands to input.txt and run.
